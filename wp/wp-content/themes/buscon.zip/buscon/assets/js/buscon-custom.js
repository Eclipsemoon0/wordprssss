(function ($) {
	"use strict";

	
})(jQuery);
